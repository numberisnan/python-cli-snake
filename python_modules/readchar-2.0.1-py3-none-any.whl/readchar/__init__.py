from .readchar import readchar, readkey
from . import key

__all__ = [readchar, readkey, key]

__version__ = '2.0.1'
